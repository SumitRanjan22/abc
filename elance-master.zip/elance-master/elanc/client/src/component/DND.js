import React from "react"
import ten1 from "../images/login1.png"


export default function DND(){
    return <img src={ten1} className="px-5 mx-5 py-3 " style={{height:'800px',width:'90%'}} alt=""/>
}