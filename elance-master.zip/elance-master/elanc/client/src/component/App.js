 import React from "react"
 import "./App.css"

// //import {Link,Route,Switch,BrowserRouter as Router} from "react-router-dom"
// //import Userpage from "./Userpage"

// import "./App.css"
// import researching from "../images/remotly.png"
// //import ten from "../images/10.jpg"
// //import ten2 from "../images/eezy_02.jpg"
// //import ten3 from "../images/eezy_04.jpg"
// import standOut from "../images/standOut.png"
// import logo from "../images/elance.jfif"
// import programming from "../images/programming.png"
// import programming1 from "../images/programming1.png"
// import content from "../images/content.png"
// import content1 from "../images/content1.png"
 import Navbar from "./Navbar"
// import design from "../images/design.png"
// import design1 from "../images/design1.png"

// import sales from "../images/sales.png"
// import sales1 from "../images/sales2.png"

// import flow from "../images/flow.png"
// import scope from "../images/scope.png"

// import iot from "../images/iot.png"


// import dataScience from "../images/dataScience.png"
// import dataScience1 from "../images/dataScience1.png"


// import {Card,Carousel} from "react-bootstrap"
import Landing from "./Landing"
function App(props){

   

    
        return (
          <div >
                   <Navbar/>
                    <Landing/>

</div>
        )
    
}

export default App;